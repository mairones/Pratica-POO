﻿//Herança e Polimorfismo Práticos em C#:
using System;

public class Funcionario
{
    public string Nome { get; set; }
    public Funcionario(string nome)
    {
        Nome = nome;
    }

    public virtual void Trabalhar()
    {
        Console.WriteLine($"{Nome} está trabalhando.");
    }
}

public class Gerente : Funcionario
{
    public Gerente(string nome) : base(nome) { }

    public override void Trabalhar()
    {
        Console.WriteLine($"{Nome} está gerenciando a equipe e organizando tarefas.");
    }
}

class Program
{
    static void Main()
    {
        Funcionario[] funcionarios = new Funcionario[]
        {
            new Funcionario("danilson"),
            new Gerente("marcao"),
            new Funcionario("nayron"),
            new Gerente("eduardo")
        };

        foreach (Funcionario f in funcionarios)
        {
            f.Trabalhar();
        }
    }
}
