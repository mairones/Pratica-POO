﻿//Encapsulamento Prático em C#:
using System;

public class ContaBancaria
{
    private double _saldo;

    public double Saldo
    {
        get { return _saldo; }
        private set
        {
            if (value < 0)
            {
                throw new ArgumentException("o saldo não pode ser negativo");
            }
            _saldo = value;
        }
    }

    public ContaBancaria(double saldoInicial)
    {
        if (saldoInicial < 0)
            throw new ArgumentException("o saldo inicial não pode ser negativo");
        _saldo = saldoInicial;
    }

    public void Depositar(double valor)
    {
        if (valor <= 0)
            throw new ArgumentException("o valor do depósito deve ser positivo");
        Saldo = _saldo + valor;
    }

    public void Sacar(double valor)
    {
        if (valor <= 0)
            throw new ArgumentException("o valor do saque deve ser positivo");
        if (valor > _saldo)
            throw new InvalidOperationException("saldo insuficiente");
        Saldo = _saldo - valor;
    }
}

class Program
{
    static void Main()
    {
        try
        {
            ContaBancaria conta = new ContaBancaria(500);
            Console.WriteLine($"Saldo inicial: R${conta.Saldo}");

            conta.Sacar(600);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro: {ex.Message}");
        }
    }
}
