﻿//Interfaces e Polimorfismo Práticos em C#:
using System;

public interface IAnimal
{
    void EmitirSom();
}

public class Cachorro : IAnimal
{
    public void EmitirSom()
    {
        Console.WriteLine("o cachorro faz miau\n");
    }
}

public class Gato : IAnimal
{
    public void EmitirSom()
    {
        Console.WriteLine("o gato faz au au\n");
    }
}

class Program
{
    static void Main()
    { 
        IAnimal[] animais = new IAnimal[]
        {
            new Cachorro(),
            new Gato(),
            new Cachorro(),
            new Gato()
        };

        foreach (IAnimal animal in animais)
        {
            animal.EmitirSom();
        }
    }
}

