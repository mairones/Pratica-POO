﻿//Abstração Prática em C#:
using System;

public abstract class Veiculo
{
    public string Modelo { get; set; }
    public abstract double CalcularVelocidadeMaxima();
}

public class Carro : Veiculo
{
    public double Potencia { get; set; } 

    public Carro(string modelo, double potencia)
    {
        Modelo = modelo;
        Potencia = potencia;
    }
    public override double CalcularVelocidadeMaxima()
    { 
        return Potencia * 1.5;
    }
}

class Program
{
    static void Main()
    {
        Carro carro = new Carro("Civic", 200);
        Console.WriteLine($"Modelo: {carro.Modelo}");
        Console.WriteLine($"Velocidade Máxima Estimada: {carro.CalcularVelocidadeMaxima()} km/h");
    }
}

