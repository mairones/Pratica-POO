﻿using System;

namespace Loja
{ 
    public abstract class Produto
    {
        public string Nome { get; set; }
        public double PrecoBase { get; set; }

        public Produto(string nome, double precoBase)
        {
            Nome = nome;
            PrecoBase = precoBase;
        }

        public abstract double CalcularPrecoFinal();
    }
    public class Eletronico : Produto
    {
        public double TaxaGarantia { get; set; }

        public Eletronico(string nome, double precoBase, double taxaGarantia)
            : base(nome, precoBase)
        {
            TaxaGarantia = taxaGarantia;
        }

        public override double CalcularPrecoFinal()
        {
            return PrecoBase * 1.15 + TaxaGarantia;
        }
    }
    public class Movel : Produto
    {
        public double TaxaEntrega { get; set; }

        public Movel(string nome, double precoBase, double taxaEntrega)
            : base(nome, precoBase)
        {
            TaxaEntrega = taxaEntrega;
        }

        public override double CalcularPrecoFinal()
        {
            return PrecoBase * 1.10 + TaxaEntrega;
        }
    }

    class Program
    {
        static void Main(string[] args)
        { 
            Produto[] produtos = new Produto[]
            {
                new Eletronico("airpods", 1000.00, 200.00),
                new Movel("mesa de jantar", 1200.00, 150.00),
                new Eletronico("celular", 2500.00, 100.00),
                new Movel("cadeira de escritorio", 800.00, 80.00)
            };

            foreach (Produto p in produtos)
            {
                Console.WriteLine($"{p.Nome} - Preço Final: R$ {p.CalcularPrecoFinal():F2}");
            }

            Console.ReadLine();
        }
    }
}
